mysql -u user -p 用于检查

cp ~/Downloads/1234.pem ~/.ssh/ 复制密钥

https://cloud.tencent.com/document/product/1207/44643 ssh 连接
- chmod 600 ~/.ssh/1234.pem      记得添加权限，不然会认定为不安全


#### 配置加速

#### 传输和解压
tar -czvf gin-mysql-demo.tar.gz .

scp 上传似乎有问题，`scp gin-mysql-demo.tar.gz root@<服务器公网IP>:/root/`
好像没有开启，直接终端中上传可以的

root 下有一个mydemo_ginsql.tar.gz 压缩文件，该怎么新建一个文件夹然后解压进去：
（千万别直接解压不然都跑出来了）

mkdir -p mydemo_ginsql
ls -al 查看
tar -zxvf ./mydemo_ginsql.tar.gz -C ./mydemo_ginsql

#### 安装 GO
为了 docker 中 go mod 下载更快 -> 设置 goproxy->需要安装 go

``` bash
sudo sed -i 's|mirrorlist=|#mirrorlist=|g' /etc/yum.repos.d/CentOS-*
sudo sed -i 's|#baseurl=http://mirror.centos.org|baseurl=https://mirrors.tencent.com/centos|g' /etc/yum.repos.d/CentOS-*
sudo dnf clean all
sudo dnf makecache
```

``` bash
sudo dnf install golang
```

``` bash
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc # 添加环境变量
source ~/.bashrc  
go env -w GOPROXY=https://mirrors.tencent.com/go/,direct # 添加代理
```

#### 补充：
```
sudo dnf update -y
sudo dnf upgrade -y
```
```
sudo dnf install -y vim wget curl git zip unzip
```
```
# 安装防火墙
sudo dnf install -y firewalld

# 启动防火墙并设置开机自启
sudo systemctl start firewalld
sudo systemctl enable firewalld

# 开放常用端口（根据需要调整）
sudo firewall-cmd --permanent --add-port=22/tcp    # SSH
sudo firewall-cmd --permanent --add-port=80/tcp    # HTTP
sudo firewall-cmd --permanent --add-port=443/tcp   # HTTPS
sudo firewall-cmd --reload
```